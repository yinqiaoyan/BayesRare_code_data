#' Compute log-sum-exp for each row (numerically stable)
#' @param L A matrix
#' @return log-sum-exp result
#' @export
rowLogSumExp <- function(L) {
  m <- apply(L, 1, max)
  m + log(rowSums(exp(L - m)))
}



#' Compute the statistical mode of a vector
#' @param v A vector
#' @return Mode of v
#' @export
getmode <- function(v) {
  uniqv <- unique(v)
  res <- uniqv[which.max(tabulate(match(v, uniqv)))]
  return(res)
}



#' Compute Shannon entropy of a probability vector
#' @param x A vector
#' @return Shannon entropy of x
#' @export
compute_entropy <- function(x) {
  x <- x[x > 0]
  return(-sum(x * log(x)))
}



#' EM algorithm: multi-subject setting with fixed new clusters
#' @param X_list_rare List of length D; the d-th element is an n_d × G matrix
#' @param mu_old0     Initial means for existing (old) clusters (G × K_init)
#' @param sig2_old0   Initial variances for existing clusters (G × K_init)
#' @param mu_new      Fixed means for new clusters (G × Kp), not updated
#' @param sig2_new    Fixed variances for new clusters (G × Kp), not updated
#' @param pi_init     Initial subject-specific mixture weights (D × (K_init+Kp));
#'     if NULL, initialize uniformly.
#'     Default is NULL.
#' @param max_iter Maximal number of iterations. Default is 200.
#' @param tol Tolerance. Default is 1e-6.
#' @param eps Small positive constant used to ensure numerical stability. Default is 1e-6.
#' @param verbose Logical; if TRUE, information of each iteration is printed. Default is TRUE.
#' @return R list: Parameters estimation results by EM.
#' \item{mu_old}{Numeric matrix (G x K_init): updated means for the candidate-rare clusters.}
#' \item{sig2_old}{Numeric matrix (G x K_init): updated variances for the candidate-rare clusters.}
#' \item{pi}{Numeric matrix (D x (K_init + K_p)): subject-specific mixture weights for all clusters; each row sums to 1.}
#' \item{R}{List of length D; each element is an n_d x (K_init + K_p)
#'   responsibility matrix with posterior membership probabilities per cell and cluster.}
#' \item{loglik}{Numeric scalar: final observed-data log-likelihood.}
#' \item{iters}{Integer scalar: number of EM iterations actually performed until stopping.}
#' @export
em_multi_subject_with_fixed_new <- function(
    X_list_rare, mu_old0, sig2_old0, mu_new, sig2_new,
    pi_init = NULL, max_iter = 200, tol = 1e-6, eps = 1e-6,
    verbose = TRUE
){
  D <- length(X_list_rare)
  G <- ncol(X_list_rare[[1]])
  n_vec <- vapply(X_list_rare, nrow, integer(1))

  K_init  <- ncol(mu_old0)
  Kp <- if (is.null(mu_new)) 0 else ncol(mu_new)
  KK <- K_init + Kp

  mu_old   <- mu_old0
  sig2_old <- pmax(sig2_old0, eps)

  # Initialize subject-specific mixture weights
  if (is.null(pi_init)) {
    pi_dk <- matrix(1/KK, nrow = D, ncol = KK)
  } else {
    stopifnot(all(dim(pi_init) == c(D, KK)))
    pi_dk <- pi_init / rowSums(pi_init)
  }

  last_ll <- -Inf
  iter <- 0
  repeat {
    iter <- iter + 1
    mu_all  <- cbind(mu_old,  mu_new)    # G x KK
    s2_all  <- cbind(sig2_old,sig2_new)  # G x KK

    ## ---------- E-step ----------
    R_list <- vector("list", D)
    ll_part <- numeric(D)
    for (d in 1:D) {
      Xd <- as.matrix(X_list_rare[[d]])     # n_d x G
      Nd <- nrow(Xd)
      logr <- matrix(0, nrow=Nd, ncol=KK)   # n_d x KK

      # Compute posterior probability of cell i from sample d belonging to cluster k
      # \pi_{ki}^{(d)} = P(Z_i^{(d)}=k|-)
      for (kk in 1:KK) {
        logr[, kk] = apply(Xd, 1, function(v){
          sum(dnorm(v, mu_all[, kk], sqrt(s2_all[, kk]), log = TRUE))
        }) + log(pi_dk[d, kk])
      }

      m  <- apply(logr, 1, max)
      Rd <- exp(logr - m)
      Rd <- Rd / rowSums(Rd)
      R_list[[d]] <- Rd
      ll_part[d]  <- sum(rowLogSumExp(logr))
    }
    ll <- sum(ll_part)

    ## ---------- M-step ----------
    # Total soft counts
    Nk_all <- Reduce("+", lapply(R_list, colSums))  # length: KK

    # Update mean for old clusters
    num_mu_old <- matrix(0, nrow = G, ncol = K_init)
    for (d in 1:D) {
      Xd <- as.matrix(X_list_rare[[d]])  # n_d * G
      Rd <- R_list[[d]][, 1:K_init, drop = FALSE]    # 仅旧簇: n_d x K_init
      num_mu_old <- num_mu_old + t(Xd) %*% Rd
    }
    Nk_old <- Nk_all[1:K_init]
    mu_old_update <- sweep(num_mu_old, 2, Nk_old, "/")

    # Update variances
    num_s2_old <- matrix(0, nrow = G, ncol = K_init)
    for (k in 1:K_init) {
      for (d in 1:D) {
        Xd <- as.matrix(X_list_rare[[d]])  # n_d x G
        rd <- R_list[[d]][, k]  # R_list[[d]]: n_d x KK
        Xc <- sweep(Xd, 2, mu_old_update[, k], "-")
        num_s2_old[, k] <- num_s2_old[, k] + colSums( (rd) * (Xc^2) )
      }
    }
    sig2_old_update <- sweep(num_s2_old, 2, Nk_old, "/")

    mu_old   <- mu_old_update
    sig2_old <- sig2_old_update


    # Update subject-specific mixture weights (K_init+Kp)
    for (d in 1:D) {
      Nd_k <- colSums(R_list[[d]])
      pi_dk[d,] <- Nd_k / sum(Nd_k)
    }

    # Check for convergence
    d_ll <- abs(ll - last_ll)
    if (verbose) cat(sprintf("iter %d: ll=%.6f, d_ll=%.3e\n", iter, ll, d_ll))
    if (iter >= max_iter || d_ll < tol) break
    last_ll <- ll
  }

  res_list = list(
    mu_old   = mu_old,
    sig2_old = sig2_old,
    pi       = pi_dk,    # D x (K_init+Kp)
    R        = R_list,   # n_d × (K_init+Kp)
    loglik   = last_ll,
    iters    = iter
  )
  return(res_list)
}



#' Logistic function
#' @param x A numeric value.
#' @return Logistic function value of x.
#' @export
logistic <- function(x) 1 / (1 + exp(-x))



#' Compute prior probability of gamma_k (cluster being rare)
#' @param mu_gk_tmp Matrix of \eqn{\mu_{gk}}
#' @param z_tmp List of cell labels for each subject.
#' @param D Number of subjects.
#' @param centers_abundant Matrix, centers of abundant clusters.
#' @param w Weights of separation and coverage. Default is c(1,1).
#' @return Prior value of \eqn{\gamma_k}.
#' @export
compute_gamma_prior <- function(mu_gk_tmp, z_tmp, D,
                                centers_abundant,
                                w = c(1, 1)) {
  b = -sum(w * 0.5)

  K_init <- ncol(mu_gk_tmp)   # number of clusters

  pk_vec = sep_vec = coverage_vec = numeric(K_init)
  zz = unlist(z_tmp)
  if (length(unique(zz)) < K_init) {
    pk_vec = rep(0.5, K_init)
    return(pk_vec)
  }

  for (k in 1:K_init) {
    # 1. Separation
    centers_compare <- rbind(mu_gk_tmp[, k], centers_abundant)
    dist_mat = dist(centers_compare)
    sep = min(dist_mat[1:nrow(centers_abundant)])

    # 2. Coverage
    coverage <- sum(sapply(1:D, function(d) {
      sum(z_tmp[[d]] == k) > 0
    })) / D

    sep_vec[k] = sep
    coverage_vec[k] = coverage
  }

  normalized_sep = normalized_vec(sep_vec)
  normalized_coverage = normalized_vec(coverage_vec)

  pk_vec <- logistic(w[1]*normalized_sep + w[2]*normalized_coverage + b)

  return(pk_vec)
}



#' Normalize a numeric vector to [0, 1]
#' @param v Numeric vector.
#' @return Normalized vector.
#' @export
normalized_vec = function(v) {
  K_init = length(v)
  if (max(v) - min(v) == 0) {
    return(rep(0.5, K_init))
  } else {
    return((v - min(v)) / (max(v) - min(v)))
  }
  return(normalized_data)
}



#' Gibbs sampler for gamma_k in the hierarchical Bayesian model
#' @param X_list A length-D list of matrices. The d-th element is an n_d x p numeric matrix
#'   of features for subject d. Rows = cells, columns = features.
#' @param K_init Integer. Number of candidate rare clusters.
#' @param centers_abundant A K_p x p numeric matrix. Each row is the
#'   feature-space center of an abundant cluster. Used to compute separation
#'   between candidate rare clusters and abundant centers.
#' @param alpha Dirichlet prior concentration for per-subject mixture weights
#'   \eqn{\pi_d}. Either a scalar or a length K_init numeric vector. Must be positive.
#' @param eta Numeric. Prior mean for cluster means \eqn{\mu_{gk}}.
#' @param tau_mu Positive scalar. Prior standard deviation for \eqn{\mu_{gk}} (used in
#'   \code{rnorm}).
#' @param nu1 Positive scalar. Shape parameter of the inverse-gamma prior for variances
#'   \eqn{\sigma^2_{gk}} when \eqn{\gamma_k = 1} (rare).
#' @param nu0 Positive scalar. Shape parameter of the inverse-gamma prior for variances
#'   \eqn{\sigma^2_{gk}} when \eqn{\gamma_k = 0} (non-rare).
#' @param tau_sigma Positive scalar. Scale parameter of the inverse-gamma prior for
#'   \eqn{\sigma^2_{gk}}.
#' @param w Weights for the prior on \eqn{\gamma_k} combining separation and coverage. Default is c(1,1).
#' @param warm_start Logical. If \code{TRUE}, initialize \eqn{Z} and \eqn{\mu}
#'   via \code{kmeans} on the pooled data; otherwise use random initialization.
#'   Default is \code{TRUE}.
#' @param num_mcmc Integer. Total number of MCMC iterations (including burn-in). Default is 100.
#' @param burnIn Integer. Number of initial iterations to discard as burn-in.
#'   Only iterations \code{> burnIn} are saved. Default is 50.
#' @param random_seed Integer. RNG seed for reproducibility. Default is 42.
#' @return R list: MCMC results including the following information.
#' \item{z}{List of lists (length D); each stores the vector of cluster assignments for all cells in each subject.}
#' \item{pi}{List of matrices (D x K_init); each stores the subject-specific mixture weights \eqn{\pi_d}.}
#' \item{mu}{List of matrices (p x K_init); each stores the sampled cluster means \eqn{\mu_{gk}} for all features and clusters.}
#' \item{sigmasq}{List of matrices (p x K_init); each stores the sampled cluster variances \eqn{\sigma^2_{gk}}.}
#' \item{gamma}{List of numeric vectors (length K_init); each stores the binary indicator
#'   \eqn{\gamma_k} for whether cluster \eqn{k} is rare (1) or non-rare (0).}
#' @export
gibbs_sampler <- function(X_list, K_init, centers_abundant,
                          alpha, eta, tau_mu, nu1, nu0, tau_sigma,
                          w=c(1, 1), warm_start=TRUE,
                          num_mcmc=100, burnIn=50, random_seed=42) {
  set.seed(random_seed)
  D <- length(X_list)           # number of subjects
  p <- ncol(X_list[[1]])        # dimension
  N_d <- sapply(X_list, nrow)   # cell number per subject

  ## Initialization
  if (warm_start) {
    X_all = do.call(rbind, X_list)  # total cell number * p_dim
    kmeans_res = kmeans(X_all, centers=K_init)

    idx <- cumsum(N_d)
    start_idx <- c(1, head(idx, -1) + 1)
    end_idx <- idx

    z <- mapply(function(s, e) kmeans_res$cluster[s:e], start_idx, end_idx, SIMPLIFY = FALSE)
    pi_all <- prop.table(table(kmeans_res$cluster))
    pi_d <- matrix(rep(pi_all, D), nrow = D, byrow = T)  # D*K_init
    mu_gk <- t(kmeans_res$centers)  # G*K_init
    sigmasq_gk <- matrix(NA, nrow = p, ncol = K_init)  # G*K_init
    gamma_k <- rbinom(K_init, 1, 0.5)
    for (k in 1:K_init) sigmasq_gk[, k] <- rinvgamma(p, ifelse(gamma_k[k] == 1, nu1, nu0), tau_sigma)
  } else {
    z <- lapply(1:D, function(d) sample(1:K_init, N_d[d], replace = TRUE))
    pi_d <- matrix(1/K_init, nrow = D, ncol = K_init)
    mu_gk <- matrix(rnorm(p*K_init, eta, tau_mu), nrow = p, ncol = K_init)
    sigmasq_gk <- matrix(NA, nrow = p, ncol = K_init)
    gamma_k <- rbinom(K_init, 1, 0.5)
    for (k in 1:K_init) sigmasq_gk[, k] <- rinvgamma(p, ifelse(gamma_k[k] == 1, nu1, nu0), tau_sigma)
  }


  ## Save results
  samples <- list(z = list(), pi = list(), mu = list(), sigmasq = list(), gamma = list())

  for (iter in 1:num_mcmc) {

    ## Update z and pi
    for (d in 1:D) {
      # -------- Update z --------

      X_d <- X_list[[d]]  # Nd*p_dim
      Nd <- N_d[d]
      tmp_mat <- matrix(0, nrow=Nd, ncol=K_init)
      for (k in 1:K_init) {
        tmp_mat[, k] = apply(X_d, 1, function(v){
          sum(dnorm(v, mu_gk[, k], sqrt(sigmasq_gk[, k]), log = TRUE))
        }) + log(pi_d[d,k])
      }

      tmp_mat <- tmp_mat - apply(tmp_mat, 1, max)
      prob_mat <- exp(tmp_mat)
      prob_mat <- prob_mat / rowSums(prob_mat)

      z[[d]] <- apply(prob_mat, 1, function(pr) sample.int(K_init, 1, prob=pr))

      # -------- Update pi_d --------
      n_k_vec_eachd <- tabulate(z[[d]], nbins = K_init)  # labels must be 1,2,...,K_init
      pi_d[d,] <- as.numeric(rdirichlet(1, alpha + n_k_vec_eachd))
    }

    ## Update gamma_k, mu_gk and sigmasq_gk
    pk_vec = compute_gamma_prior(mu_gk, z, D, centers_abundant, w)

    for (k in 1:K_init) {
      X_k <- do.call(rbind, lapply(1:D, function(d) {
        idx <- which(z[[d]] == k)
        if (length(idx) > 0) X_list[[d]][idx, , drop = FALSE]
      }))
      n_k <- nrow(X_k)

      if (is.null(X_k)) {
        gamma_k[k] = rbinom(1, 1, 0.5)
        mu_gk[, k] <- rnorm(p, eta, tau_mu)
        sigmasq_gk[, k] <- rinvgamma(p, ifelse(gamma_k[k] == 1, nu1, nu0), tau_sigma)
      } else {
        logRk = log(pk_vec[k]) - log(1 - pk_vec[k]) +
          p * (
            lgamma(nu1 + n_k / 2) - lgamma(nu0 + n_k / 2) - lgamma(nu1) + lgamma(nu0)
          ) + (nu1 - nu0) *
          (p * log(tau_sigma) - sum(
            log(tau_sigma + 0.5 * colSums((X_k - matrix(mu_gk[, k], nrow(X_k), ncol(X_k), byrow=T))^2))
          ))

        p1 = 1 / (1 + exp(-logRk))
        gamma_k[k] = rbinom(1, 1, p1)

        # posterior var: ( n_k / sigma2_{gk} + 1/tau_mu^2 )^{-1}
        post_var <- 1 / (n_k / sigmasq_gk[, k] + 1 / tau_mu^2)
        post_mean <- post_var * ( colSums(X_k) / sigmasq_gk[, k] + eta / tau_mu^2 )
        mu_gk[, k] <- rnorm(p, mean=post_mean, sd=sqrt(post_var))

        post_shape <- ifelse(gamma_k[k] == 1, nu1, nu0) + n_k / 2
        post_scale <- tau_sigma + 0.5 * colSums((X_k - matrix(mu_gk[, k], nrow(X_k), ncol(X_k), byrow=T))^2)
        sigmasq_gk[,k] <- rinvgamma(p, shape=post_shape, scale=post_scale)

      }
    }


    ## Save results
    if (iter > burnIn) {
      samples$z[[iter - burnIn]] <- z
      samples$pi[[iter - burnIn]] <- pi_d
      samples$mu[[iter - burnIn]] <- mu_gk
      samples$sigmasq[[iter - burnIn]] <- sigmasq_gk
      samples$gamma[[iter - burnIn]] <- gamma_k
    }
  }

  return(samples)
}



#' Weighted permutation test on subject-level posterior summaries
#'
#' @description
#' Performs a permutation test for the between-group difference in
#' cell-count–weighted means of subject-level posterior mixing proportions
#' for a single rare cluster. Group labels are permuted at the subject level
#' to avoid cell-level pseudoreplication.
#'
#' @param y Numeric vector of length D: subject-level posterior mixing proportions
#'   (e.g., posterior mean of \eqn{\pi_{dk}}) for one cluster.
#' @param g Factor/character vector of length D: group labels (e.g., "patient"/"control").
#' @param w Optional numeric vector of length D: subject weights (default \eqn{w=1});
#'   typically set to each subject's total cell count.
#' @param nperm Integer. Number of label permutations. Default is \code{10000L}.
#' @param alternative Character. Type of alternative hypothesis:
#'   \code{"two.sided"} (default), \code{"greater"}, or \code{"less"}.
#' @param seed Integer. Random seed for reproducibility. Default is 42.
#' @return
#' \item{stat}{Observed test statistic \code{T}.}
#' \item{p.value}{Permutation p-value (according to \code{alternative}).}
#' \item{null}{Numeric vector of length \code{nperm}: permuted statistics \eqn{T^{(b)}}.}
#' \item{alternative}{The alternative hypothesis used.}
#' @export
perm_test_weighted <- function(y,                # numeric: subject-level posterior summary of pi_{dk}
                               g,                # factor/char: group labels, e.g., "patient"/"control"
                               w = NULL,         # numeric weights per subject; default 1
                               nperm = 10000L,   # permutations
                               alternative = c("two.sided","greater","less"),
                               seed = 42) {
  stopifnot(length(y) == length(g))
  if (is.null(w)) w <- rep(1, length(y))
  alternative <- match.arg(alternative)
  if (!is.null(seed)) set.seed(seed)

  stat_fun <- function(y, g, w) {
    g <- as.factor(g)
    lev <- levels(g)
    A <- g == lev[1]; B <- !A
    wm <- function(x, ww) sum(ww * x) / sum(ww)
    wm(y[A], w[A]) - wm(y[B], w[B])
  }

  T_obs <- stat_fun(y, g, w)

  # permute group labels at subject level
  T_perm <- numeric(nperm)
  for (b in seq_len(nperm)) {
    T_perm[b] <- stat_fun(y, sample(g), w)
  }

  # p-value
  if (alternative == "two.sided") {
    p <- (1 + sum(abs(T_perm) >= abs(T_obs))) / (nperm + 1)
  } else if (alternative == "greater") {
    p <- (1 + sum(T_perm >= T_obs)) / (nperm + 1)
  } else {
    p <- (1 + sum(T_perm <= T_obs)) / (nperm + 1)
  }

  list(stat = T_obs, p.value = p, null = T_perm, alternative = alternative)
}
