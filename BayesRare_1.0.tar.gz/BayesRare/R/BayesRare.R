#' Preprocess BayesRare inputs and derive fixed abundant-cluster moments via Seurat
#'
#' @description
#' This function prepares inputs for BayesRare by (i) splitting candidate rare-cell
#' PCs into a per-subject list \code{X_list}, and (ii) using Seurat on the
#' non-rare PCs to obtain abundant-cluster centers (means/variances) that are
#' kept fixed in the subsequent EM step.
#'
#' @param expr_pc A numeric matrix/data frame of principal components
#'   (rows = cells, columns = PCs) with the first column reserved
#'   for an ID. The function uses \code{expr_pc[, -1]} as the PC matrix.
#' @param meta_data A data frame with per-cell metadata; must contain a column
#'   \code{donor_id} giving the subject ID for each row (cell).
#' @param initial_clust_res A data frame containing a column named
#'   \code{rare_subcluster_id}. Cells with \code{rare_subcluster_id != -1}
#'   are treated as candidate rare cells, and the number of unique non-\code{-1}
#'   values is used to define \code{K_init}. (number of unique \code{rare_subcluster_id != -1} is used as K_init);
#'   \code{-1} marks non-rare cells used to estimate abundant-cluster moments.
#' @param random_seed_seurat Integer seed for Seurat neighbor graph and
#'   clustering to ensure reproducible abundant-cluster estimation. Default is \code{42}.
#' @importFrom Seurat CreateSeuratObject CreateDimReducObject FindNeighbors FindClusters DefaultAssay
#' @return A named list with:
#' \item{X_list}{List of length D (subjects). Each element is a numeric
#'   matrix (cells x PCs) containing the PCs of candidate rare cells for that subject.}
#' \item{K_init}{Integer. Initial number of candidate rare clusters
#'   inferred from \code{initial_clust_res} as \code{length(unique(rare_subcluster_id)) - 1}.}
#' \item{mu_gk_fixed}{Matrix of size G x K_p. PC-wise means of the
#'   abundant clusters obtained from Seurat (kept fixed in EM). Columns correspond to abundant clusters.}
#' \item{sigmasq_gk_fixed}{Matrix of size G x K_p. PC-wise variances of the
#'   abundant clusters obtained from Seurat (kept fixed in EM). Columns correspond to abundant clusters.}
#' @export
data_preprocess <- function(expr_pc, meta_data, initial_clust_res, random_seed_seurat=42) {
  expr_pc_data = expr_pc[, -1] # cells x nPCs

  K_init = length(unique(initial_clust_res$rare_subcluster_id)) - 1
  rare_candidates_id = which(initial_clust_res$rare_subcluster_id != -1)
  nonrare_candidates_id = which(initial_clust_res$rare_subcluster_id == -1)

  expr_pc_data_cand = expr_pc_data[rare_candidates_id, ]
  expr_pc_data_nonrare = expr_pc_data[nonrare_candidates_id, ]
  patients_id = meta_data$donor_id[rare_candidates_id]

  ## X_list data
  rownames(expr_pc_data_cand) <- rare_candidates_id
  X_list <- split.data.frame(expr_pc_data_cand, patients_id)

  cat("## Conduct Seurat...\n")
  pca_mat <- as.matrix(expr_pc_data_nonrare)

  ncells <- nrow(pca_mat)
  npc    <- ncol(pca_mat)

  rownames(pca_mat) <- paste0("Cell_", seq_len(ncells))
  colnames(pca_mat) <- paste0("PC_", seq_len(npc))

  feature_name <- "fakegene"  # 不要用 fake_gene
  placeholder_counts <- matrix(0, nrow=npc, ncol=ncells)

  ## Create Seurat object
  obj <- Seurat::CreateSeuratObject(counts = placeholder_counts, project = "FromPCA")
  Seurat::DefaultAssay(obj) <- "RNA"

  ## Create dimension reduction object by PCs
  # Rows: cells, columns: dimensions
  pca_dr <- Seurat::CreateDimReducObject(
    embeddings = pca_mat,
    key = "PC_",
    assay = Seurat::DefaultAssay(obj)
  )
  obj[["pca"]] <- pca_dr

  ## Generate neighborhood and conduct clustering based on PCs
  use_dims <- 1:npc
  set.seed(random_seed_seurat)
  obj <- Seurat::FindNeighbors(obj, reduction = "pca", dims = use_dims)
  obj <- Seurat::FindClusters(obj, resolution = 0.1)
  cat("## Seurat complete!\n")

  mu_gk_fixed = NULL
  sigmasq_gk_fixed = NULL

  res_seurat = as.numeric(obj@meta.data[["seurat_clusters"]])
  uniq_seurat = sort(unique(res_seurat))

  for (k_abund in seq_len(length(uniq_seurat))) {
    tmp_ids = which(res_seurat == uniq_seurat[k_abund])
    tmp_expr = expr_pc_data_nonrare[tmp_ids, ]
    mu_gk_fixed = cbind(mu_gk_fixed, colMeans(tmp_expr))
    sigmasq_gk_fixed = cbind(sigmasq_gk_fixed, apply(tmp_expr, 2, var))
  }

  outputs = list(X_list=X_list,
                 K_init=K_init,
                 mu_gk_fixed=mu_gk_fixed,
                 sigmasq_gk_fixed=sigmasq_gk_fixed)
  return(outputs)
}



#' Implement BayesRare for population-level rare cell detection in multi-subject scRNA-seq
#'
#' @description
#' This function runs the full BayesRare pipeline: (i) MCMC-based Bayesian
#' clustering of candidate rare cells across subjects with a sparsity prior on
#' clusters, (ii) selection of of final detected rare populations from candidate
#' clusters via posterior inclusion probabilities, and (iii) an EM refinement
#' that fixes abundant-cluster moments and updates rare clusters to reduce false positives.
#' Optionally, it performs basic two-group inference (patients vs. controls).
#'
#' @param X_list A list of numeric matrices of length D (subjects).
#'   The d-th element is an n_d x G matrix of per-cell features
#'   (e.g., PCs) for subject d. Row names are used as cell IDs when saving results.
#' @param K_init Integer. Initial number of candidate rare clusters (before
#'   posterior selection). Typically the number of unique candidate subclusters
#'   obtained from an upstream detector.
#' @param mu_gk_fixed A G x K_p numeric matrix: fixed means (per feature)
#'   for K_p abundant clusters obtained from non-rare cells (e.g., Seurat
#'   clustering on abundant cells).
#' @param sigmasq_gk_fixed A G x K_p numeric matrix: fixed variances
#'   (per feature) for the same K_p abundant clusters.
#' @param patient_group_ids Integer vector of subject indices defining group 1
#'   (e.g., patients). Used only when \code{do_test = TRUE}.
#' @param control_group_ids Integer vector of subject indices defining group 2
#'   (e.g., healthy controls). Used only when \code{do_test = TRUE}.
#' @param alpha (gibbs_sampler input) Dirichlet prior concentration for per-subject mixture weights
#'   \eqn{\pi_d}. Either a scalar or a length K_init numeric vector. Must be positive.
#' @param eta (gibbs_sampler input) Numeric. Prior mean for cluster means \eqn{\mu_{gk}}.
#' @param tau_mu (gibbs_sampler input) Positive scalar. Prior standard deviation for \eqn{\mu_{gk}} (used in
#'   \code{rnorm}).
#' @param nu1 (gibbs_sampler input) Positive scalar. Shape parameter of the inverse-gamma prior for variances
#'   \eqn{\sigma^2_{gk}} when \eqn{\gamma_k = 1} (rare).
#' @param nu0 (gibbs_sampler input) Positive scalar. Shape parameter of the inverse-gamma prior for variances
#'   \eqn{\sigma^2_{gk}} when \eqn{\gamma_k = 0} (non-rare).
#' @param tau_sigma (gibbs_sampler input) Positive scalar. Scale parameter of the inverse-gamma prior for
#'   \eqn{\sigma^2_{gk}}.
#' @param w (gibbs_sampler input) Weights for the prior on \eqn{\gamma_k} combining separation and coverage. Default is c(1,1).
#' @param warm_start (gibbs_sampler input) Logical. If \code{TRUE}, initialize \eqn{Z} and \eqn{\mu}
#'   via \code{kmeans} on the pooled data; otherwise use random initialization.
#'   Default is \code{TRUE}.
#' @param num_mcmc (gibbs_sampler input) Integer. Total number of MCMC iterations (including burn-in). Default is 100.
#' @param burnIn (gibbs_sampler input) Integer. Number of initial iterations to discard as burn-in.
#'   Only iterations \code{> burnIn} are saved. Default is 50.
#' @param random_seed (gibbs_sampler input) Integer. RNG seed for reproducibility. Default is 42.
#' @param do_test Logical. If \code{TRUE}, perform a two-group comparison
#'   on posterior cluster proportions (permutation test) and compute credible
#'   intervals for group differences.
#' @param sig_level Numeric scalar in (0,1). Significance level used in the
#'   permutation test. Default is 0.05.
#' @param verbose_time Logical. If \code{TRUE}, print total execution time for MCMC
#'   and EM phases.
#' @param verbose_em Logical. If \code{TRUE}, print EM iteration progress and
#'   log-likelihood changes.
#'
#' @importFrom MCMCpack rdirichlet rinvgamma
#'
#' @return
#' If \code{do_test = FALSE}, returns a list with:
#' \item{rare_ids}{Integer vector of cell IDs retained after EM refinement.}
#' \item{rare_labels}{Integer vector of final rare cluster labels for \code{rare_ids}
#'   (cluster indices after the MCMC selection and EM).}
#' \item{z_res}{List of length D. The d-th element is a numeric vector containing
#'   cell-to-cluster assignments for subject d (values in \code{1..K_init}).}
#'
#' If \code{do_test = TRUE}, returns a list with:
#' \item{rare_ids}{As above.}
#' \item{rare_labels}{As above.}
#' \item{z_res}{List of length D. The d-th element is a numeric vector containing
#'   cell-to-cluster assignments for subject d (values in \code{1..K_init}).}
#' \item{p_values}{Numeric vector of permutation testing p-values comparing group-averaged
#'   posterior proportions (patients vs. controls) for each final rare cluster.}
#' \item{CI_values_for_sig}{Numeric matrix with three columns \code{(2.5\%, 50\%, 97.5\%)},
#'   reporting the posterior median and 95% credible interval (2.5% and 97.5% quantiles)
#'   of the between-group differences in cluster mixing proportions across MCMC samples
#'   for rare clusters with p-value less than the significance level.}
#' @export
BayesRare_train <- function(X_list, K_init, mu_gk_fixed, sigmasq_gk_fixed,
                            patient_group_ids=NULL, control_group_ids=NULL,
                            alpha=1, eta=0, tau_mu=1, nu1=2, nu0=1, tau_sigma=1,
                            w=c(1, 1), warm_start=TRUE,
                            num_mcmc=1000, burnIn=500, random_seed=42,
                            do_test=FALSE, sig_level=0.05,
                            verbose_time=FALSE, verbose_em=FALSE) {

  D = length(X_list)
  centers_abundant = t(mu_gk_fixed)

  cat("## BayesRare training...\n")
  ss.time = Sys.time()
  res_mcmc <- gibbs_sampler(
    X_list=X_list, K_init=K_init, centers_abundant=centers_abundant,
    alpha=alpha, eta=eta, tau_mu=tau_mu, nu1=nu1, nu0=nu0, tau_sigma=tau_sigma,
    w=w, warm_start=warm_start,
    num_mcmc=num_mcmc, burnIn=burnIn, random_seed=random_seed
  )
  ee.time = Sys.time()
  save_time_bayesrare = ee.time - ss.time
  cat("## BayesRare training complete!\n")

  gamma_mat = t(sapply(res_mcmc$gamma, rbind))

  z_res = vector("list", D)
  for (d in 1:D) {
    z_res[[d]] = apply(t(sapply(res_mcmc$z, function(ll){ll[[d]]})), 2, getmode)
  }

  gamma_prop = apply(gamma_mat, 2, function(v){sum(v == 1) / nrow(gamma_mat)})
  names(gamma_prop) = 1:length(gamma_prop)

  rare_candidates_post = which(gamma_prop > 0.5)

  if (length(rare_candidates_post) == 0) {
    cat("No rare cell cluster is detected.\n")
    outputs <- list(gamma_prop=gamma_prop, z_res=z_res)
    return(outputs)
  }


  ## use EM after posterior inference
  cat("## EM algorithm...\n")

  Kp = ncol(mu_gk_fixed)
  mu_new_fixed = mu_gk_fixed  # G x Kp
  sig2_new_fixed = sigmasq_gk_fixed

  n <- length(res_mcmc$pi)
  pi_res <- Reduce("+", res_mcmc$pi) / n
  mu_res <- Reduce("+", res_mcmc$mu) / n
  sigmasq_res <- Reduce("+", res_mcmc$sigmasq) / n

  pi_res_after = pi_res[, rare_candidates_post]
  mu_res_after = mu_res[, rare_candidates_post]
  sigmasq_res_after = sigmasq_res[, rare_candidates_post]

  pi_new_all = 0.1
  pi_init = cbind(pi_res_after, matrix(pi_new_all/Kp, nrow=D, ncol=Kp))
  pi_init = pi_init / rowSums(pi_init)

  X_list_rare = vector("list", D)
  for (d in 1:D) {
    X_list_rare[[d]] = X_list[[d]][z_res[[d]] %in% rare_candidates_post, ]
  }

  mu_old0 = as.matrix(mu_res_after)  # mu_res_after may be 1-dim vector
  sig2_old0 = as.matrix(sigmasq_res_after)

  ## Run EM
  ss_time_em = Sys.time()
  fit <- em_multi_subject_with_fixed_new(
    X_list_rare,
    mu_old0   = mu_old0,
    sig2_old0 = sig2_old0,
    mu_new    = mu_new_fixed,
    sig2_new  = sig2_new_fixed,
    pi_init   = pi_init,
    max_iter = 200, tol = 1e-6, verbose = verbose_em
  )

  ee_time_em = Sys.time()
  save_time_em = ee_time_em - ss_time_em
  cat("## EM algorithm complete!\n")

  if (verbose_time) {
    cat("## Execution time of MCMC & EM: ")
    cat(sprintf("%.2f mins & ", as.numeric(save_time_bayesrare, units = "mins")))
    cat(sprintf("%.2f mins\n", as.numeric(save_time_em, units = "mins")))

    cat("## Total execution time: ")
    cat(sprintf("%.2f mins\n", as.numeric(save_time_bayesrare + save_time_em, units = "mins")))
  }

  ## Save rare ids
  save_id_list = z_res_after_list = vector("list", D)
  threshold = log(ncol(fit$pi)) / 1e3

  for (d in 1:D) {
    ids_d = rownames(X_list[[d]])
    ids_d_now1 = ids_d[z_res[[d]] %in% rare_candidates_post]
    tmp_z_res_post = z_res[[d]][z_res[[d]] %in% rare_candidates_post]

    tmp_entropy = apply(fit$R[[d]], 1, function(v){
      compute_entropy(v)
    })
    save_id_list[[d]] = ids_d_now1[tmp_entropy <= threshold]
    z_res_after_list[[d]] = tmp_z_res_post[tmp_entropy <= threshold]
  }

  final_id_unlist = as.numeric(unlist(save_id_list))
  z_res_after_unlist = unlist(z_res_after_list)


  if (do_test) {
    ## Statistical inference
    cat("## Conduct statistical inference.\n")

    n_mat = matrix(nrow = D, ncol = K_init)
    for (rr in 1:D) {
      for (kk in 1:K_init) {
        n_mat[rr, kk] = sum(z_res[[rr]] == kk)
      }
    }

    mean_mat <- Reduce(`+`, res_mcmc$pi) / length(res_mcmc$pi)

    subj_labels = vector("character", D)
    subj_labels[patient_group_ids] = "patient"
    subj_labels[control_group_ids] = "control"

    p_vec = numeric(length(rare_candidates_post))
    for (kk in 1:length(rare_candidates_post)) {
      out <- perm_test_weighted(y = mean_mat[, rare_candidates_post[kk]], g = subj_labels, w = rowSums(n_mat), nperm = 2e4, seed = 1)
      p_vec[kk] = out$p.value
    }

    sig_clusters = which(p_vec < sig_level)


    ## CI for group-level difference
    CI_mat = matrix(nrow = length(sig_clusters), ncol = 3)
    delta_s = matrix(nrow = num_mcmc - burnIn, ncol = length(sig_clusters))
    for (each_iter in seq_len(num_mcmc - burnIn)) {
      pi_each = res_mcmc$pi[[each_iter]]
      tmp_mat_patient = as.matrix(pi_each[patient_group_ids, rare_candidates_post[sig_clusters]])
      tmp_mat_control = as.matrix(pi_each[control_group_ids, rare_candidates_post[sig_clusters]])
      tmp_mat_patient_avg  <- colSums(tmp_mat_patient  * rowSums(n_mat[patient_group_ids, ])) /
        sum(rowSums(n_mat[patient_group_ids, ]))
      tmp_mat_control_avg  <- colSums(tmp_mat_control  * rowSums(n_mat[control_group_ids, ])) /
        sum(rowSums(n_mat[control_group_ids, ]))

      delta_s[each_iter, ] <- tmp_mat_patient_avg - tmp_mat_control_avg
    }
    for (kk in 1:length(sig_clusters)) {
      CI_mat[kk, ] =  quantile(delta_s[ ,kk], c(0.025, 0.5, 0.975))
    }

    ## Outputs if do_test=TRUE
    names(p_vec) = paste0("C", rare_candidates_post)
    rownames(CI_mat) = paste0("C", rare_candidates_post[sig_clusters])
    colnames(CI_mat) = c("2.5%", "50%", "97.5%")
    outputs <- list(gamma_prop=gamma_prop, rare_ids=final_id_unlist,
                    rare_labels=z_res_after_unlist, z_res=z_res,
                    mu_K_init=res_mcmc$mu, sigmasq_K_init=res_mcmc$sigmasq,
                    p_values=p_vec, CI_values_for_sig=CI_mat)
    return(outputs)

  } else {
    ## Outputs if do_test=FALSE
    outputs <- list(gamma_prop=gamma_prop, rare_ids=final_id_unlist,
                    rare_labels=z_res_after_unlist, z_res=z_res,
                    mu_K_init=res_mcmc$mu, sigmasq_K_init=res_mcmc$sigmasq,)
    return(outputs)
  }

}


